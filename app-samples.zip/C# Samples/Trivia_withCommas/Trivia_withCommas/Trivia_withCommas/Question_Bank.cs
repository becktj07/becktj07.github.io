﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Trivia_withCommas
{
    class Question_Bank
    {

        const int NO_OF_QUESTIONS = 10;
        const int NO_OF_ANSWERS = 4;
        string[] temp = new string[7];
        Question_Unit[] questionBank = new Question_Unit[NO_OF_QUESTIONS];

        string fileName = "Trivia.txt";


        public int ReadQuestionFile()
        {
            string aRecord;
            int index = 0;

            StreamReader filStream = new StreamReader(fileName);

            aRecord = filStream.ReadLine();
            while (aRecord != null)
            {
                temp = aRecord.Split(',');
                questionBank[index] = new Question_Unit();
                questionBank[index].Question = temp[0];

                for (int x = 0; x < NO_OF_ANSWERS; x++)
                {
                    questionBank[index].Answer[x] = temp[x + 1];
                }


                questionBank[index].CorrectAnswer = temp[5];
                questionBank[index].Explanation = temp[6]; ;

                index++;
                aRecord = filStream.ReadLine();
            }

            return index;
        }

        public string GetQuestion(int index)
        {
            return questionBank[index].Question;
        }
        public string[] GetAnswers(int index)
        {
            string[] answers = new string[NO_OF_ANSWERS];
            answers = questionBank[index].Answer;

            return answers;
        }
        public string GetCorrectAnswer(int index)
        {
            return questionBank[index].CorrectAnswer;
        }
        public string GetExplanation(int index)
        {
            return questionBank[index].Explanation;
        }


    }
}
