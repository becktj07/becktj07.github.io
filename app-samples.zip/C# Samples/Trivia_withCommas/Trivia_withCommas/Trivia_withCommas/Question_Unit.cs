﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trivia_withCommas
{
    class Question_Unit
    {

        string question;
        string[] answer = new string[4];
        string correctAnswer;
        private string explanation;

        public string Question
        {
            set
            {
                question = value;
            }
            get
            {
                return question;
            }
        }

        public string[] Answer
        {
            set
            {
                answer = value;
            }
            get
            {
                return answer;
            }
        }


        public string CorrectAnswer
        {
            set
            {
                correctAnswer = value;
            }
            get
            {
                return correctAnswer;
            }
        }

        public string Explanation
        {
            set
            {
                explanation = value;
            }
            get
            {
                return explanation;
            }
        }

    }
}
