﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trivia_withCommas
{
    class Program
    {
        static void Main(string[] args)
        { 
            Controller userIO = new Controller();
            userIO.Play();
        }
    }
}
