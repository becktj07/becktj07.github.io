﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace JumbleGame
{
	class UIJumble
	{
		public UIJumble()
		{
		}

		public void DisplayWelcome()
		{
			Console.WriteLine("");
			Console.WriteLine("------------------------------------------------------------------");
			Console.WriteLine("");
			Console.WriteLine("Welcome to the Word Jumble Game. I will randomly pick a word\n" +
							  "and display it to you with the letters mixed up. You will try\n" +
							  "and guess the word. I will tell you when you are correct.");
			Console.WriteLine("");
			Console.WriteLine("------------------------------------------------------------------");
			Console.WriteLine("");
			Console.WriteLine("Hit the enter key when you are ready to play.");
			Console.ReadLine();
			Console.Clear();
		}

		public void PlayGame()
		{
			string userGuess;
			char playAgain = 'y';

			do {
    			Jumble jumble = new Jumble();
                jumble.GenerateRandomWord(jumble.wordBank);
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine("the selected word: " + jumble.selectedWord);
                jumble.ScrambleWord(jumble.selectedWord);
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("The scrambled word is...  ");
                Console.Write(jumble.displayWord);
                Console.WriteLine("\nEnter your guess:");
                userGuess = Console.ReadLine();
                jumble.CompareResult(jumble.selectedWord, userGuess);
				Console.WriteLine("\nWant to play again? Enter y/n.");
				playAgain = Console.ReadKey().KeyChar;
                Console.Clear();
			} while (playAgain == 'y');   
		}
        
		public void Goodbye()
		{
			Console.WriteLine("Thanks for playing.");
			Thread.Sleep(2000);
			Console.Clear();
			Console.WriteLine("Goodbye.");
			Console.ReadLine();
		}
	}
}
