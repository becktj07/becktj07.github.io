﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JumbleGame
{
    class Info
    {
        public Info()
        {
        }

        public void DisplayInfo()
        {
            Console.WriteLine("Name:\t\t Tyler Beck");
            Console.WriteLine("Course:\t\t ITDEV 115");
            Console.WriteLine("Instructor:\t Robert Menzl");
            Console.WriteLine("Assignment:\t Assignment 2 - Jumble Game");
            Console.WriteLine("Date:\t\t 9/25/18");
        }
    }
}
