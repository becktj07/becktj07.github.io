﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JumbleGame
{
    class Jumble
    {
        public string[] wordBank = { "dog", "burrito", "car" };
        public string selectedWord;
        public char[] displayWord;

        public Jumble(){
			
		}

        public string GenerateRandomWord(string[] _wordBank)
        {
            Random random = new Random();
            int i = random.Next(0, wordBank.Length);
            selectedWord = wordBank[i];

            return selectedWord;
        }

		public string ScrambleWord(string _selectedWord)
		{
			displayWord = new char[_selectedWord.Length];
			Random rand = new Random(10000);
			int index = 0;
			while (_selectedWord.Length > 0)
			{
				int next = rand.Next(0, _selectedWord.Length - 1); // Take the character from the random position and add to the array. 
				displayWord[index] = _selectedWord[next];          // Remove the character from the word.
				_selectedWord = _selectedWord.Substring(0, next) + _selectedWord.Substring(next + 1);
				++index;
			}

			return new String(displayWord);
		}

        public void CompareResult(string correctWord, string userGuess)
        {
            if (correctWord == userGuess)
            {
                Console.WriteLine("You are correct!");
            }
            else
            {
                Console.WriteLine("Wrong! The selected word was " + selectedWord + ".");
            }
        }
    }
}
