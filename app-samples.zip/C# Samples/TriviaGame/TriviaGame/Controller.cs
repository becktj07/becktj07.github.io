﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriviaGame
{
    class Controller
    {
        public Controller()
        {

        }
        public void Welcome()
        {
            Info info = new Info();
            info.DisplayInfo();
            Console.WriteLine("\nWelcome to the trivia game. You will be given four questions.");
            Console.WriteLine("Choose the correct answer by entering the letter of your choice.");
            Console.WriteLine("\nPress enter to continue");
            Console.ReadLine();
        }

        public void Play()
        {
            Welcome();
            QuestionBank file = new QuestionBank();
            file.ReadFile();
        }
    }
}
