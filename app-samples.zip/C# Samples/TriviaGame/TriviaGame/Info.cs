﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriviaGame
{
    class Info
    {
        public Info()
        {
        }
        public void DisplayInfo()
        {
            Console.WriteLine("Name:\t\t Tyler Beck");
            Console.WriteLine("Course:\t\t ITDEV 115");
            Console.WriteLine("Instructor:\t Robert Menzl");
            Console.WriteLine("Assignment:\t Trivia Game App");
            Console.WriteLine("Date:\t\t 12/01/18");
            Console.WriteLine("------------------------------------------------");
            Console.WriteLine();
        }
    }
}
