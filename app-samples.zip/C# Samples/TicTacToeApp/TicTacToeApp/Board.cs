﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeApp
{
    class Board
    {
        public Board() { }

        public void DisplayGameState(string[] _spaces, string _errorMessage)
        {
            Console.WriteLine();
            Console.WriteLine("\t\t" + _spaces[0] + "|" + _spaces[1] + "|" + _spaces[2]);
            Console.WriteLine("\t\t------");
            Console.WriteLine("\t\t" + _spaces[3] + "|" + _spaces[4] + "|" + _spaces[5]);
            Console.WriteLine("\t\t------");
            Console.WriteLine("\t\t" + _spaces[6] + "|" + _spaces[7] + "|" + _spaces[8]);

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(_errorMessage);
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
