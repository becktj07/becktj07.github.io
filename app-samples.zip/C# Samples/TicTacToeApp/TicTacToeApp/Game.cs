﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeApp
{
    class Game
    {
        public Game()
        {
        }

        public string[] space = new string[9];
        public int selection;
        public string playAgain = "y";
        public void Play()
        {
            Player player = new Player();
            Board board = new Board();
            for (int i = 0; i < 9; i++)
            {
                player.spaces[i] = i.ToString();
            }

            while (playAgain == "y" || selection < 9)
            {
                board.DisplayGameState(player.spaces, player.errorMessage);
                Console.WriteLine("Player " + player.currentPlayer);
                Console.Write("Enter your selection: ");
                selection = Convert.ToInt32(Console.ReadLine());

                while(selection > 9)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nERROR: Must enter a number between 0 and 8.");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("Player " + player.currentPlayer);
                    Console.Write("Enter your selection: ");
                    selection = Convert.ToInt32(Console.ReadLine());
                } 

                player.Move(selection);
                player.CheckBoard(player.spaces);
                Console.Clear();
                if (player.winner != null || player.winner == "It's a tie.")
                {
                    board.DisplayGameState(player.spaces, player.errorMessage);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(player.winner);
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("Want to play another game?");
                    Console.WriteLine("y/n");
                    //reset if yes
                    playAgain = Console.ReadLine();
                    Console.Clear();
                    for (int i = 0; i < 9; i++)
                    {
                        player.spaces[i] = i.ToString();
                    }
                    player.winner = null;

                    if (playAgain == "n")
                    {
                        Environment.Exit(0);
                    }
                }
            }
        }
    }
}
