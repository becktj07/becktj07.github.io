﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeApp
{
    class Info
    {
        public Info()
        {
        }

        public void DisplayInfo()
        {
            Console.WriteLine("Name:\t\t Tyler Beck");
            Console.WriteLine("Course:\t\t ITDEV 115");
            Console.WriteLine("Instructor:\t Robert Menzl");
            Console.WriteLine("Assignment:\t Tic Tac Toe App");
            Console.WriteLine("Date:\t\t 11/20/18");
            Console.WriteLine("------------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("Press any key to continue.");
            Console.ReadLine();
            Console.Clear();
        }
    }
}
