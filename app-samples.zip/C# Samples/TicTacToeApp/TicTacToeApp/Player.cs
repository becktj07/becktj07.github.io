﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeApp
{
    class Player
    {
        public Player()
        {
            player = Pieces.X;
        }
        public enum Pieces
        {
            X,
            O
        }

        public Pieces player = Pieces.X;
        public string[] spaces = new string[9];
        public string currentPlayer = "X";
        public string errorMessage = "";
        public string winner;
        public string result = "no error";
        public string Move(int selection)
        { 
            if (spaces[selection] == "O" || spaces[selection] == "X")
            {
                errorMessage = "ERROR: That spot is already taken. Try again.";
                return errorMessage;
            }

            else
            {
                if (player == Pieces.X && spaces[selection] != "O")
                {
                    spaces[selection] = "X";
                    currentPlayer = "O";
                    player = Pieces.O;
                    errorMessage = "";
                    return result;
                }

                else if (player == Pieces.O && spaces[selection] != "X")
                {
                    spaces[selection] = "O";
                    currentPlayer = "X";
                    player = Pieces.X;
                    errorMessage = "";
                    return result;
                }

                errorMessage = "";
                return result;
            }
        }

        public string CheckBoard(string[] _spaces)
        {
            //spaces 0,1,2
            if (_spaces[0].Contains("X") && _spaces[1].Contains("X") && _spaces[2].Contains("X"))
            {
                winner = "Player X has won.";
                return winner;
            }

            else if (_spaces[0].Contains("O") && _spaces[1].Contains("O") && _spaces[2].Contains("O"))
            {
                winner = "Player O has won.";
                return winner;
            }

            //spaces 3,4,5
            else if (_spaces[3].Contains("X") && _spaces[4].Contains("X") && _spaces[5].Contains("X"))
            {
                winner = "Player X has won.";
                return winner;
            }

            else if (_spaces[3].Contains("O") && _spaces[4].Contains("O") && _spaces[5].Contains("O"))
            {
                winner = "Player O has won.";
                return winner;
            }

            // spaces 6 ,7, 8
            else if (_spaces[6].Contains("X") && _spaces[7].Contains("X") && _spaces[8].Contains("X"))
            {
                winner = "Player X has won.";
                return winner;
            }

            else if (_spaces[6].Contains("O") && _spaces[7].Contains("O") && _spaces[8].Contains("O"))
            {
                winner = "Player O has won.";
                return winner;
            }

            //spaces 0,3,6
            else if (_spaces[0].Contains("X") && _spaces[3].Contains("X") && _spaces[5].Contains("X"))
            {
                winner = "Player X has won.";
                return winner;
            }

            else if (_spaces[0].Contains("O") && _spaces[3].Contains("O") && _spaces[5].Contains("O"))
            {
                winner = "Player O has won.";
                return winner;
            }

            //spaces 1,4,7
            else if (_spaces[1].Contains("X") && _spaces[4].Contains("X") && _spaces[7].Contains("X"))
            {
                winner = "Player X has won.";
                return winner;
            }

            else if (_spaces[1].Contains("O") && _spaces[4].Contains("O") && _spaces[7].Contains("O"))
            {
                winner = "Player O has won.";
                return winner;
            }
            //spaces 2,5,8
            else if (_spaces[2].Contains("X") && _spaces[5].Contains("X") && _spaces[8].Contains("X"))
            {
                winner = "Player X has won.";
                return winner;
            }

            else if (_spaces[2].Contains("O") && _spaces[5].Contains("O") && _spaces[8].Contains("O"))
            {
                winner = "Player O has won.";
                return winner;
            }

            //spaces 0, 4, 8
            else if (_spaces[0].Contains("X") && _spaces[4].Contains("X") && _spaces[8].Contains("X"))
            {
                winner = "Player X has won.";
                return winner;
            }

            else if (_spaces[0].Contains("O") && _spaces[4].Contains("O") && _spaces[8].Contains("O"))
            {
                winner = "Player O has won.";
                return winner;
            }
            
            //spaces 2, 4, 6
            else if (_spaces[2].Contains("X") && _spaces[4].Contains("X") && _spaces[6].Contains("X"))
            {
                winner = "Player X has won.";
                return winner;
            }

            else if (_spaces[2].Contains("O") && _spaces[4].Contains("O") && _spaces[6].Contains("O"))
            {
                winner = "Player O has won.";
                return winner;
            }

            // its a draw
            else if(_spaces.Contains("0") == false && _spaces.Contains("1") == false && _spaces.Contains("2") == false && _spaces.Contains("3") == false && _spaces.Contains("4") == false && _spaces.Contains("5") == false && _spaces.Contains("6") == false && _spaces.Contains("7") == false && _spaces.Contains("8") == false)
            {
                winner = "It's a tie.";
                return winner;
            }
            else 

            return null;
        }
    }
}
