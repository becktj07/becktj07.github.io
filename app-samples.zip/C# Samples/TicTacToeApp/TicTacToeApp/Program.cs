﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Info info = new Info();
            info.DisplayInfo();
            Game game = new Game();
            game.Play();
            Console.ReadLine();
        }
    }
}
