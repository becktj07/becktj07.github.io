﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam
{
    class Info
    {
        public Info()
        {
        }

        public void DisplayInfo()
        {
            Console.WriteLine("Name:\t\t Tyler Beck");
            Console.WriteLine("Course:\t\t ITDEV 115");
            Console.WriteLine("Instructor:\t Robert Menzl");
            Console.WriteLine("Assignment:\t Final Exam - Student List");
            Console.WriteLine("Date:\t\t 12/15/18");
            Console.WriteLine("------------------------------------------------");
            Console.WriteLine();
        }
    }
}
