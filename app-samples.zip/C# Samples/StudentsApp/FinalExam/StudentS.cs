﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO; //add for file io.

/******************************
 * Student: Tyler Beck
 * Purpose: Students Class - hold List of Students
 ************************************/

namespace FinalExam
{
    class StudentS
    {
        public string fileName = "grades.txt";
        public void PopulateStudents(string _fileName)
        {
            var theStudentList = new List<Student>();

            string line;
            string[] singleValue = new string[23];

            StreamReader fileStream = new StreamReader(_fileName);

            line = fileStream.ReadLine();

            while (line != "")
            {
                singleValue = line.Split(',');
                Student aStudent = new Student();
                aStudent.studentID = singleValue[0];
                aStudent.nameFirst = singleValue[1];
                aStudent.nameLast = singleValue[2];

                for (int i = 3; i < 23; i++)
                {
                    var _earned = int.Parse(singleValue[i]);
                    aStudent.earned.Add(_earned);
                    i++;
                    var _possible = int.Parse(singleValue[i]);
                    aStudent.possible.Add(_possible);
                }

                aStudent.earnedSum = aStudent.earned.Sum();
                aStudent.possibleSum = aStudent.possible.Sum();

                aStudent.average = aStudent.CalAverage(aStudent.earnedSum, aStudent.possibleSum);
                aStudent.letterGrade = aStudent.CalGrade(aStudent.average);

                theStudentList.Add(aStudent);
                line = fileStream.ReadLine();
            }

            foreach (Student s in theStudentList)
            {
                Console.WriteLine(" {0} \t {1}    \t {2}    \t {3}     \t {4}", s.studentID, s.nameFirst, s.nameLast, s.average, s.letterGrade);
            }
        }
    }
}
