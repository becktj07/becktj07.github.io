﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/******************************
 * Student: Your Name
 * Purpose: Student Grades -- Arrays
 ******************************/

namespace FinalExam
{

    class Student
    {
        //data member
        public string nameFirst;
        public string nameLast;
        public string studentID;
        public List<int> earned;
        public int earnedSum;
        public List<int> possible;
        public int possibleSum;
        public float average;
        public string letterGrade;

        public Student() //default constructor
        {
            studentID = null;
            earned = new List<int>();
            possible = new List<int>();
            average = 0;
            letterGrade = null;
        }

        public float CalAverage(int _earnedSum, int _possibleSum)
        {
            average = (float)_earnedSum / _possibleSum;
            average = (float)Math.Round(average, 2);

            return average;
        }

        public string CalGrade(float _average)
        {
            if (average >= .90)
                letterGrade = "A";

            if (average >= .80 && average < .90)
                letterGrade = "B";

            if (average >= .70 && average < .80)
                letterGrade = "C";

            if (average >= .60 && average < .70)
                letterGrade = "D";

            if (average < .60)
                letterGrade = "U";

            return letterGrade;
        }
    }
}
