﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam
{
    class GradesUI
    {
        //public string fileName = "grades.txt";
        //public void MainMethod()
        //{
        //    //instance an object of StudentS..
        //    StudentS myStudentS = new StudentS();

        //    //Call StudentUI->PopulateStudents

        //    //Verify file was successfully read.
        //    //if successfull call DisplayInfo()
        //    try
        //    {
        //        myStudentS.PopulateStudents(fileName);
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine("{0} Exception caught.", e);
        //    }

        //    foreach (Student in )
        //    {

        //    }
        //    DisplayInfo(myStudentS);
        //}

        //public void DisplayInfo(StudentS _myStudentS)
        //{
        //    Console.WriteLine("Student id\tLast Name\tAverage  \tGrade");

        //    for (int index = 0; index < _myStudentS.ListLength; index++)
        //    {
        //        Console.WriteLine(" {0} \t {1}    \t {2}    \t {3}", _myStudentS.StudentID(index), _myStudentS.StudentLastName(index), _myStudentS.StudentAverage(index), _myStudentS.StudentGrade(index));
        //    }
        //}
    }
}
