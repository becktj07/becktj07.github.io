﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam
{
    class Program
    {
        static void Main(string[] args)
        {
            Info info = new Info();
            info.DisplayInfo();
            StudentS studentList = new StudentS();
            try
            {
                studentList.PopulateStudents(studentList.fileName);
            }
            catch (Exception e)
            {
                Console.WriteLine("An error occurred: '{0}'", e);
            }
            Console.ReadLine();
        }
    }
}
