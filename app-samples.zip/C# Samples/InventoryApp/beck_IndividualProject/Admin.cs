﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace beck_IndividualProject
{
    class Admin
    {
        public void ConsoleSetup()
        {
            Console.WindowHeight = 35;
            Console.WindowWidth = 100;
            Console.Title = "Rexcon Product Inventory Manager / Sales Estimator";
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
        }
        public void WelcomeScreen()
        {
            Console.WriteLine(
            @"      
                   ---------------------------------------------------------
                                       ** REXCON GLOBAL **
                   ---------------------------------------------------------
                                             _____   
                                            /\    \         
                                           /::\    \                
                                          /::::\    \                      
                                         /::::::\    \                 
                                        /:::/\:::\    \           
                                       /:::/__\:::\    \              
                                      /::::\   \:::\    \            
                                     /::::::\   \:::\    \         
                                    /:::/\:::\   \:::\____\        
                                   /:::/  \:::\   \:::|    |       
                                   \::/   |::::\  /:::|____|       
                                    \/____|:::::\/:::/    /                     
                                          |::|    _ _ _ _/                    
                                          |::|   |                 
                                          \::|   |                       
                                           \:|   |               
                                            \|___|            ");

            Thread.Sleep(1000);
            Console.Beep(659, 125);
            Console.WriteLine("\n\n\t\t\t\t   Press Enter to Continue.");
            Console.ReadLine();
            Console.Clear();
        }
    }
}
