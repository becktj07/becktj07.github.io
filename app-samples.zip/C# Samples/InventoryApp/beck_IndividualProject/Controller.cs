﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace beck_IndividualProject
{
    class Controller
    {
        private int appSelector;
        public void TakeControl()
        {
            do
            {
                //Select the area of the app
                Console.WriteLine("\nPress 1: Product/Inventory Manager");
                Console.WriteLine("Press 2: Sales Commission Calculator");
                Console.WriteLine("Press 3: QUIT");
                appSelector = int.Parse(Console.ReadLine());
                Console.Clear();

                switch (appSelector)
                {
                    case 1:
                        Product product = new Product();
                        product.CurrentProductDatabase();
                        product.CreateNewProduct();
                        Console.Clear();
                        break;
                    case 2:
                        SalesCalculator salesCalculator = new SalesCalculator();
                        salesCalculator.CalculateCommission();
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Number not recognized.");
                        Console.ForegroundColor = ConsoleColor.Green;
                        break;
                }
            } while (appSelector != 1 || appSelector != 2 || appSelector != 3);
        }
    }
}
