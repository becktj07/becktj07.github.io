﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace beck_IndividualProject
{
    class Product
    {
        private string productName;
        private int productSKU;
        private int quantity;
        private double manufacturerCost;
        private double MSRP;
        private char addAnotherProduct = 'y';
        public void CurrentProductDatabase()
        {
            int currentTotalProducts;

            List<Product> productListing = new List<Product>
            {
                new Product{productName = "XGears", productSKU = 78295, quantity = 345, manufacturerCost = 350.44, MSRP = 500.00},
                new Product{productName = "Roller", productSKU = 28488, quantity = 20, manufacturerCost = 200.00, MSRP = 220.00},
                new Product{productName = "Bearing", productSKU = 55537, quantity = 999, manufacturerCost = 850.75, MSRP = 990.00}
            };
            currentTotalProducts = productListing.Count;

            Console.WriteLine(
            @"PRODUCT NAME    SKU       QTY.  COST      MSRP");
            foreach (var product in productListing)
            {
                Console.WriteLine((product.productName) + ("\t\t") + ("#") + (product.productSKU) + ("\t  ") + (product.quantity) + ("\t") + ("$") + (product.manufacturerCost) + ("\t  ") + ("$") + (product.MSRP));
            }
            Console.WriteLine("\nTotal Products: " + currentTotalProducts);
        }
        public void CreateNewProduct()
        {
            int productIndex;
            string newProductName;
            int newProductSKU;
            int newProductQuantity;
            double newProductManufacturerCost;
            double newProductMSRP;

            List<Product> productListing = new List<Product>
                {
                    new Product{productName = "GearZ", productSKU = 78295, quantity = 345, manufacturerCost = 350.44, MSRP = 500.00},
                    new Product{productName = "Rollers", productSKU = 28488, quantity = 20, manufacturerCost = 200.00, MSRP = 220.00},
                    new Product{productName = "Bearing", productSKU = 55537, quantity = 999, manufacturerCost = 850.75, MSRP = 990.00}
                };

            do
            {
                Console.WriteLine("\n\nWant to add a new product?");
                Console.WriteLine("Press y to add, n to exit;");
                addAnotherProduct = char.Parse(Console.ReadLine());
                productIndex = productListing.Count;

                if (addAnotherProduct == 'n')
                {
                    break;
                }

                Console.Clear();
                Console.WriteLine("Enter the product name:");
                newProductName = Console.ReadLine();
                Console.Clear();
                Console.WriteLine("Enter the 5 digit product SKU:");
                newProductSKU = int.Parse(Console.ReadLine());
                Console.Clear();
                Console.WriteLine("Enter the quantity that will be warehoused:");
                newProductQuantity = int.Parse(Console.ReadLine());
                Console.Clear();
                Console.WriteLine("Enter the manufactuer cost:");
                newProductManufacturerCost = double.Parse(Console.ReadLine());
                Console.Clear();
                Console.WriteLine("Enter the MSRP:");
                newProductMSRP = double.Parse(Console.ReadLine());
                Console.Clear();

                productListing.Insert(productIndex, new Product() { productName = (newProductName), productSKU = (newProductSKU), quantity = (newProductQuantity), manufacturerCost = (newProductManufacturerCost), MSRP = (newProductMSRP) });

                Console.Clear();
                Console.WriteLine(
                @"PRODUCT_NAME    SKU       QTY.  COST      MSRP");
                foreach (var product in productListing)
                {
                    Console.WriteLine((product.productName) + ("\t\t") + ("#") + (product.productSKU) + ("\t  ") + (product.quantity) + ("\t") + ("$") + (product.manufacturerCost) + ("\t  ") + ("$") + (product.MSRP));
                }
                productIndex++;

            } while (addAnotherProduct == 'y');
        }
    }
}
