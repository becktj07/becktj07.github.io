﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace beck_IndividualProject
{
    class SalesCalculator
    {
        private int productID;
        private int amountSold;
        private double manufacturerCost;
        private double MSRP;
        private double totalCommission;
        private char addAnotherProduct = 'y';
        public void CalculateCommission()
        {
            Console.WriteLine("Your sales commission will be 40% of the difference between");
            Console.WriteLine("the manufacturer cost, and the MSRP of the product.");

            while (addAnotherProduct == 'y')
            {
                do
                {
                    Console.WriteLine("\nEnter the product id number.");
                    productID = int.Parse(Console.ReadLine());

                    switch (productID)
                    {
                        case 1:
                            {
                                manufacturerCost = 350;
                                MSRP = 500;
                                break;
                            }
                        case 2:
                            {
                                manufacturerCost = 10;
                                MSRP = 75;
                                break;
                            }
                        default:
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("ERROR: Invalid product ID.");
                            Console.ForegroundColor = ConsoleColor.Green;
                            break;
                    }
                } while (productID > 2);

                Console.Clear();
                Console.WriteLine("\nEnter the quantity you are selling.");
                amountSold = int.Parse(Console.ReadLine());
                Console.Clear();
                totalCommission = ((MSRP - manufacturerCost) * (amountSold)) * .4;
                Thread.Sleep(1500);
                Console.WriteLine("\nIf you sell " + (amountSold) + " units of product " + (productID));
                Console.WriteLine("you will earn " + ("$") + (totalCommission) + " in commission.");
                Console.WriteLine("\nWant to calculate another product?");
                Console.WriteLine("Press y to continue, n to exit.");
                addAnotherProduct = char.Parse(Console.ReadLine());
                Console.Clear();
            } 
        }
    }
}