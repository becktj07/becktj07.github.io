﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace beck_IndividualProject
{
    class App
    {
        static void Main(string[] args)
        {
            Admin admin = new Admin();
            admin.ConsoleSetup();
            admin.WelcomeScreen();
            Controller controller = new Controller();
            controller.TakeControl();
        }
    }
}